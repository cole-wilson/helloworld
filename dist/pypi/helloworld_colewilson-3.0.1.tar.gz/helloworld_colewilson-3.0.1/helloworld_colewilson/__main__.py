print('Hello, World!')
input() # Wait for user input to close