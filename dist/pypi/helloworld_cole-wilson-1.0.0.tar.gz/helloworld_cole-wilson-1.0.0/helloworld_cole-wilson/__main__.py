print('Hello, World!')
input('')